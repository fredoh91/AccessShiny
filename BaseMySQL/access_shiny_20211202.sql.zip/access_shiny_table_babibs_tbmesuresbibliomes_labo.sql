
-- --------------------------------------------------------

--
-- Structure de la table `babibs_tbmesuresbibliomes_labo`
--

CREATE TABLE `babibs_tbmesuresbibliomes_labo` (
  `idMesure` int(11) DEFAULT NULL,
  `IdSignal` int(11) DEFAULT NULL,
  `idBiblio` int(11) DEFAULT NULL,
  `idMesusage` int(11) DEFAULT NULL,
  `libelleMesure` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `avisDP` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dateAvisDP` timestamp NULL DEFAULT NULL,
  `auteurDP` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `avisDSURV` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dateAvisDSURV` timestamp NULL DEFAULT NULL,
  `auteurDSURV` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `avisBoard` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dateAvisBoard` timestamp NULL DEFAULT NULL,
  `auteurBOARD` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `motif` text COLLATE utf8_unicode_ci,
  `UtilisateurCreaModif` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `datePrevision` timestamp NULL DEFAULT NULL,
  `dateMiseOeuvre` timestamp NULL DEFAULT NULL,
  `FlNonMisEnOeuvre` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Déchargement des données de la table `babibs_tbmesuresbibliomes_labo`
--

INSERT INTO `babibs_tbmesuresbibliomes_labo` (`idMesure`, `IdSignal`, `idBiblio`, `idMesusage`, `libelleMesure`, `avisDP`, `dateAvisDP`, `auteurDP`, `avisDSURV`, `dateAvisDSURV`, `auteurDSURV`, `avisBoard`, `dateAvisBoard`, `auteurBOARD`, `motif`, `UtilisateurCreaModif`, `datePrevision`, `dateMiseOeuvre`, `FlNonMisEnOeuvre`) VALUES
(597, 629, 0, 0, 'Action de réduction ANSM-import', 'Oui', '2019-02-08 22:49:48', 'Frannou', 'Oui', '2019-02-08 22:49:48', 'Frannou', NULL, NULL, NULL, 'Surveillance spécifique\nProchain PSUR\n', NULL, NULL, NULL, 0),
(598, 633, 0, 0, 'Action de réduction ANSM-import', 'Oui', '2019-02-08 22:49:48', 'Frannou', 'Oui', '2019-02-08 22:49:48', 'Frannou', NULL, NULL, NULL, 'Communication + Mesures de réduction du risque', NULL, NULL, NULL, 0),
(599, 634, 0, 0, 'Action de réduction ANSM-import', 'Oui', '2019-02-08 22:49:48', 'Frannou', 'Oui', '2019-02-08 22:49:48', 'Frannou', NULL, NULL, NULL, 'Communication + Mesures de réduction du risque', NULL, NULL, NULL, 0),
(600, 635, 0, 0, 'Action de réduction ANSM-import', 'Oui', '2019-02-08 22:49:48', 'Frannou', 'Oui', '2019-02-08 22:49:48', 'Frannou', NULL, NULL, NULL, 'Communication + Mesures de réduction du risque', NULL, NULL, NULL, 0),
(601, 636, 0, 0, 'Action de réduction ANSM-import', 'Oui', '2019-02-08 22:49:48', 'Frannou', 'Oui', '2019-02-08 22:49:48', 'Frannou', NULL, NULL, NULL, 'Communication + Mesures de réduction du risque', NULL, NULL, NULL, 0),
(602, 637, 0, 0, 'Action de réduction ANSM-import', 'Oui', '2019-02-08 22:49:48', 'Frannou', 'Oui', '2019-02-08 22:49:48', 'Frannou', NULL, NULL, NULL, '01/10/2016 : Communication', NULL, NULL, NULL, 0),
(603, 638, 0, 0, 'Action de réduction ANSM-import', 'Oui', '2019-02-08 22:49:48', 'Frannou', 'Oui', '2019-02-08 22:49:48', 'Frannou', NULL, NULL, NULL, '01/10/2016 : Communication', NULL, NULL, NULL, 0),
(604, 641, 0, 0, 'Action de réduction ANSM-import', 'Oui', '2019-02-08 22:49:48', 'Frannou', 'Oui', '2019-02-08 22:49:48', 'Frannou', NULL, NULL, NULL, '28/08/2017 : Communication + modification AMM + surveillance spécifique', NULL, NULL, NULL, 0),
(605, 646, 0, 0, 'Action de réduction ANSM-import', 'Oui', '2019-02-08 22:49:49', 'Frannou', 'Oui', '2019-02-08 22:49:49', 'Frannou', NULL, NULL, NULL, '01/01/2017 : Mesures de réduction du risque', NULL, NULL, NULL, 0),
(606, 665, 0, 0, 'Action de réduction ANSM-import', 'Oui', '2019-02-08 22:49:51', 'Frannou', 'Oui', '2019-02-08 22:49:51', 'Frannou', NULL, NULL, NULL, 'Communication + modification AMM + surveillance spécifique', NULL, NULL, NULL, 0),
(607, 666, 0, 0, 'Action de réduction ANSM-import', 'Oui', '2019-02-08 22:49:51', 'Frannou', 'Oui', '2019-02-08 22:49:51', 'Frannou', NULL, NULL, NULL, '01/01/2017 : Communication', NULL, NULL, NULL, 0),
(608, 673, 0, 0, 'Action de réduction ANSM-import', 'Oui', '2019-02-08 22:49:51', 'Frannou', 'Oui', '2019-02-08 22:49:51', 'Frannou', NULL, NULL, NULL, 'Modification AMM + surveillance spécifique', NULL, NULL, NULL, 0),
(609, 675, 0, 0, 'Action de réduction ANSM-import', 'Oui', '2019-02-08 22:49:51', 'Frannou', 'Oui', '2019-02-08 22:49:51', 'Frannou', NULL, NULL, NULL, '31/03/2017 : Communication', NULL, NULL, NULL, 0),
(610, 682, 0, 0, 'Action de réduction ANSM-import', 'Oui', '2019-02-08 22:49:52', 'Frannou', 'Oui', '2019-02-08 22:49:52', 'Frannou', NULL, NULL, NULL, '12/12/2017 : Communication', NULL, NULL, NULL, 0),
(611, 684, 0, 0, 'Action de réduction ANSM-import', 'Oui', '2019-02-08 22:49:52', 'Frannou', 'Oui', '2019-02-08 22:49:52', 'Frannou', NULL, NULL, NULL, '15/11/2017 : Mesures de réduction du risque + Surveillance spécifique', NULL, NULL, NULL, 0),
(612, 704, 0, 0, 'Action de réduction ANSM-import', 'Oui', '2019-02-08 22:49:52', 'Frannou', 'Oui', '2019-02-08 22:49:52', 'Frannou', NULL, NULL, NULL, 'Modification du RCP afin d\'allonger la durée maximale de traitement à 12 mois (alignement sur le RCP d\'Enantone)', NULL, NULL, NULL, 0),
(613, 720, 0, 0, 'Action de réduction ANSM-import', 'Oui', '2019-02-08 22:49:53', 'Frannou', 'Oui', '2019-02-08 22:49:53', 'Frannou', NULL, NULL, NULL, '25/07/2017 : Mesures de réduction du risque', NULL, NULL, NULL, 0),
(614, 721, 0, 0, 'Action de réduction ANSM-import', 'Oui', '2019-02-08 22:49:53', 'Frannou', 'Oui', '2019-02-08 22:49:53', 'Frannou', NULL, NULL, NULL, '25/07/2017 : Mesures de réduction du risque', NULL, NULL, NULL, 0),
(574, 330, 0, 0, 'Action de réduction ANSM-import', 'Oui', '2019-02-08 22:49:37', 'Frannou', 'Oui', '2019-02-08 22:49:37', 'Frannou', NULL, NULL, NULL, ' - ', NULL, NULL, NULL, 0),
(575, 338, 0, 0, 'Action de réduction ANSM-import', 'Oui', '2019-02-08 22:49:38', 'Frannou', 'Oui', '2019-02-08 22:49:38', 'Frannou', NULL, NULL, NULL, 'Communication + Mesures de réduction du risque', NULL, NULL, NULL, 0),
(576, 357, 0, 0, 'Action de réduction ANSM-import', 'Oui', '2019-02-08 22:49:38', 'Frannou', 'Oui', '2019-02-08 22:49:38', 'Frannou', NULL, NULL, NULL, ' - ', NULL, NULL, NULL, 0),
(577, 365, 0, 0, 'Action de réduction ANSM-import', 'Oui', '2019-02-08 22:49:39', 'Frannou', 'Oui', '2019-02-08 22:49:39', 'Frannou', NULL, NULL, NULL, '13/05/2015 : Communication', NULL, NULL, NULL, 0),
(578, 373, 0, 0, 'Action de réduction ANSM-import', 'Oui', '2019-02-08 22:49:39', 'Frannou', 'Oui', '2019-02-08 22:49:39', 'Frannou', NULL, NULL, NULL, '13/05/2015 : Communication', NULL, NULL, NULL, 0),
(579, 375, 0, 0, 'Action de réduction ANSM-import', 'Oui', '2019-02-08 22:49:39', 'Frannou', 'Oui', '2019-02-08 22:49:39', 'Frannou', NULL, NULL, NULL, '13/05/2015 : Communication', NULL, NULL, NULL, 0),
(580, 376, 0, 0, 'Action de réduction ANSM-import', 'Oui', '2019-02-08 22:49:39', 'Frannou', 'Oui', '2019-02-08 22:49:39', 'Frannou', NULL, NULL, NULL, '14/04/2017 : Communication', NULL, NULL, NULL, 0),
(581, 389, 0, 0, 'Action de réduction ANSM-import', 'Oui', '2019-02-08 22:49:39', 'Frannou', 'Oui', '2019-02-08 22:49:39', 'Frannou', NULL, NULL, NULL, '28/01/2016 : Communication', NULL, NULL, NULL, 0),
(582, 399, 0, 0, 'Action de réduction ANSM-import', 'Oui', '2019-02-08 22:49:40', 'Frannou', 'Oui', '2019-02-08 22:49:40', 'Frannou', NULL, NULL, NULL, '05/04/2016 : Communication + Mesures de réduction du risque', NULL, NULL, NULL, 0),
(583, 425, 0, 0, 'Action de réduction ANSM-import', 'Oui', '2019-02-08 22:49:40', 'Frannou', 'Oui', '2019-02-08 22:49:40', 'Frannou', NULL, NULL, NULL, 'Communication + Mesures de réduction du risque', NULL, NULL, NULL, 0),
(584, 435, 0, 0, 'Action de réduction ANSM-import', 'Oui', '2019-02-08 22:49:41', 'Frannou', 'Oui', '2019-02-08 22:49:41', 'Frannou', NULL, NULL, NULL, 'Communication', NULL, NULL, NULL, 0),
(585, 445, 0, 0, 'Action de réduction ANSM-import', 'Oui', '2019-02-08 22:49:41', 'Frannou', 'Oui', '2019-02-08 22:49:41', 'Frannou', NULL, NULL, NULL, '05/04/2016 : Communication + Mesures de réduction du risque', NULL, NULL, NULL, 0),
(586, 447, 0, 0, 'Action de réduction ANSM-import', 'Oui', '2019-02-08 22:49:42', 'Frannou', 'Oui', '2019-02-08 22:49:42', 'Frannou', NULL, NULL, NULL, 'Communication', NULL, NULL, NULL, 0),
(587, 449, 0, 0, 'Action de réduction ANSM-import', 'Oui', '2019-02-08 22:49:42', 'Frannou', 'Oui', '2019-02-08 22:49:42', 'Frannou', NULL, NULL, NULL, '05/04/2016 : Communication + Mesures de réduction du risque', NULL, NULL, NULL, 0),
(588, 477, 0, 0, 'Action de réduction ANSM-import', 'Oui', '2019-02-08 22:49:42', 'Frannou', 'Oui', '2019-02-08 22:49:42', 'Frannou', NULL, NULL, NULL, 'Surveillance spécifique', NULL, NULL, NULL, 0),
(589, 479, 0, 0, 'Action de réduction ANSM-import', 'Oui', '2019-02-08 22:49:43', 'Frannou', 'Oui', '2019-02-08 22:49:43', 'Frannou', NULL, NULL, NULL, '05/11/2015 : Mesures de minimisation du risque', NULL, NULL, NULL, 0),
(590, 492, 0, 0, 'Action de réduction ANSM-import', 'Oui', '2019-02-08 22:49:43', 'Frannou', 'Oui', '2019-02-08 22:49:43', 'Frannou', NULL, NULL, NULL, 'Communication + Surveillance renforcée', NULL, NULL, NULL, 0),
(591, 494, 0, 0, 'Action de réduction ANSM-import', 'Oui', '2019-02-08 22:49:43', 'Frannou', 'Oui', '2019-02-08 22:49:43', 'Frannou', NULL, NULL, NULL, 'Modification AMM - Nouvelle AMM\n(En attente)', NULL, NULL, NULL, 0),
(592, 506, 0, 0, 'Action de réduction ANSM-import', 'Oui', '2019-02-08 22:49:43', 'Frannou', 'Oui', '2019-02-08 22:49:43', 'Frannou', NULL, NULL, NULL, 'EIT', NULL, NULL, NULL, 0),
(593, 524, 0, 0, 'Action de réduction ANSM-import', 'Oui', '2019-02-08 22:49:44', 'Frannou', 'Oui', '2019-02-08 22:49:44', 'Frannou', NULL, NULL, NULL, '03/03/2016 : Communication', NULL, NULL, NULL, 0),
(594, 526, 0, 0, 'Action de réduction ANSM-import', 'Oui', '2019-02-08 22:49:44', 'Frannou', 'Oui', '2019-02-08 22:49:44', 'Frannou', NULL, NULL, NULL, '06/10/2016 : Communication', NULL, NULL, NULL, 0),
(595, 551, 0, 0, 'Action de réduction ANSM-import', 'Oui', '2019-02-08 22:49:45', 'Frannou', 'Oui', '2019-02-08 22:49:45', 'Frannou', NULL, NULL, NULL, '05/04/2016 : Communication + Mesures de réduction du risque', NULL, NULL, NULL, 0),
(596, 553, 0, 0, 'Action de réduction ANSM-import', 'Oui', '2019-02-08 22:49:45', 'Frannou', 'Oui', '2019-02-08 22:49:45', 'Frannou', NULL, NULL, NULL, '05/04/2016 : Communication + Mesures de réduction du risque', NULL, NULL, NULL, 0),
(616, 758, 0, 0, 'Revue de données', 'Oui', '2019-10-29 23:00:00', NULL, 'Oui', '2019-12-02 23:00:00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-07-29 22:00:00', 0),
(617, 1071, 0, 0, 'Pas d\'action ou mesure', 'Oui', '2020-08-16 22:00:00', 'PATRAS-DE-CAMPAIGNO', NULL, NULL, NULL, NULL, NULL, NULL, 'RTU déjà en cours d\'instruction en DP1', NULL, NULL, NULL, 0);
